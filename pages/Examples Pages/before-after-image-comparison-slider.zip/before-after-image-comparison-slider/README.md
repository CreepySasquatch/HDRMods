# before & after image comparison slider

A Pen created on CodePen.

Original URL: [https://codepen.io/shortfuse/pen/dyxrjGj](https://codepen.io/shortfuse/pen/dyxrjGj).

testing out http://thenewcode.com/819/A-Before-And-After-Image-Comparison-Slide-Control-in-HTML5